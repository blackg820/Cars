<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class welcomecontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $citty = DB::table('cities')
            ->join('colleges', 'cities.id', '=', 'colleges.city_id')
            ->select('cities.*', 'colleges.*')
            ->get();
        // dd($citty);
        return view('Welcome')->with(['cities' => $citty]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        if ($request->search != null) {
            $citty = DB::table('cities')
                ->join('colleges', 'cities.id', '=', 'colleges.city_id')
                ->select('cities.*', 'colleges.*')
                ->get();
            $users = DB::table('users')
                ->join('profiles', 'users.id', '=', 'profiles.user_id')
                ->join('cities', 'profiles.from', '=', 'cities.id')
                ->join('colleges', 'colleges.city_id', '=', 'cities.id')
                ->join('addresses', 'addresses.user_id', '=', 'users.id')
                ->select('users.name', 'users.email', 'profiles.phone', 'profiles.price', 'profiles.car_type', 'profiles.car_model', 'cities.city', 'colleges.college')
                ->where('colleges.id', '=', $request->Cityselect)
                ->where('addresses.address', 'like', '%' . $request->search . '%')
                ->orderBy('price', 'asc')
                ->get();
            // dd($users);
            return view('Welcome')->with(['cities' => $citty, 'users' => $users]);
        } else {
            $citty = DB::table('cities')
                ->join('colleges', 'cities.id', '=', 'colleges.city_id')
                ->select('cities.*', 'colleges.*')
                ->get();
            // dd($citty);
            return view('Welcome')->with(['cities' => $citty]);
        }
    }
}
