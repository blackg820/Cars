<?php $__env->startSection('title', 'Home page'); ?>

<?php $__env->startSection('content'); ?>

<div>
    <h1 style="text-align: center;">Hello to sweet home :)
    </h1>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test11\resources\views/welcome.blade.php ENDPATH**/ ?>